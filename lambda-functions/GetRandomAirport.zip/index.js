const AWS = require('aws-sdk');
const ddb = new AWS.DynamoDB.DocumentClient();
const ddbbase = new AWS.DynamoDB();
const GeographicLib = require("geographiclib");
const geod = GeographicLib.Geodesic.WGS84;

exports.handler = (event, context, callback) => {

    console.log('Received event ', event);

    // The body field of the event in a proxy integration is a raw string.
    // In order to extract meaningful values, we need to first parse this string
    // into an object. A more robust implementation might inspect the Content-Type
    // header first and use a different parsing strategy based on that value.

    //Get requested origin airport
    //TODO actually take in origin and radius from the form
    //TODO maybe put this into two chained lambda functions?
    var originLat;
    var originLon;
    var params = {
        AttributesToGet: [
            "lattitude",
            "longitude"
        ],
        TableName: "Airports",
        Key : {
            "icao" : {
                "S" : "KILM"
            }
        }
    };
    ddbbase.getItem(params, function(err, data) {
        if (err) {
            console.log(err);
            errorResponse(err.message, context.awsRequestId, callback);
        }
        else {
            console.log("origin data: ", data);
            originLat = data.lattitude;
            originLon = data.longitude;
        }
    });



    //TODO change to take distance into account
    var params = {
        TableName: "Airports",
        IndexName: 'countryCode-index',
        ExpressionAttributeValues: {
            ":countryCode": "US"
        },
        KeyConditionExpression: "countryCode = :countryCode",
        Limit: 50
    };
    ddb.query(params, function(err, data) {
        if (err) {
            console.log(err);
            errorResponse(err.message, context.awsRequestId, callback);
        }
        else {
            if (data.Items) {
                var airport = data.Items[Math.floor(Math.random()*data.Items.length)];
                //airport = data.Items[0];
                callback(null, {
                    statusCode:201,
                    body: JSON.stringify({
                        AirportName: airport.name,
                        AirportCode: airport.icao,
                        //TODO make function to calculate
                        DistanceFromOrigin: 200,
                        Country: airport.Country
                    }),
                    headers: {
                        'Access-Control-Allow-Origin': '*',
                    },
                });
            }
            else {
                errorResponse('No airports found within the selected radius.', context.awsRequestId, callback);
            }
            console.log('response from dynamo: ', data)
        }
    });
};

function errorResponse(errorMessage, awsRequestId, callback) {
  callback(null, {
    statusCode: 500,
    body: JSON.stringify({
      Error: errorMessage,
      Reference: awsRequestId,
    }),
    headers: {
      'Access-Control-Allow-Origin': '*',
    },
  });
}

function getBounds(lat, lon, radiusInMiles) {
    radius = milesToKm(radiusInMiles);
    var northWestBound = geod.Direct(lat, lon, 315, radius);
    var southEastBound = geod.Direct(lat, lon, 135, radius);
    console.log("The northWestBound is (" + northWestBound.lat2.toFixed(8) + ", " + northWestBound.lon2.toFixed(8) + ").");
    console.log("The southEastBound is (" + southEastBound.lat2.toFixed(8) + ", " + southEastBound.lon2.toFixed(8) + ").");
}

function milesToKm(miles) {
    return miles * 1.609344;
}